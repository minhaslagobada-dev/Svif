const screenIds=["landing","modalScreen","aboutPage"];
const pages=["emailPage","verifyPage","confirmPage","donePage"];
let flowMode="login";
function showScreen(id){screenIds.forEach(x=>document.getElementById(x).classList.toggle("active",x===id))}
function showPage(id){
 pages.forEach(x=>document.getElementById(x).classList.toggle("active",x===id));
 const stage={emailPage:0,verifyPage:1,confirmPage:2,donePage:2}[id]||0;
 ["labelLogin","labelVerify","labelConfirm"].forEach((x,i)=>document.getElementById(x).classList.toggle("current",i===stage));
 const width=["0%","50%","100%"][stage];
 document.getElementById("progressFill").style.width=width;
 document.getElementById("progressDot").style.left=["0%","50%","96%"][stage];
}
function openFlow(mode){flowMode=mode;document.getElementById("emailTitle").textContent=mode==="create"?"Create your Supercell ID":"Log in with your Supercell ID";document.getElementById("emailDescription").textContent=mode==="create"?"Enter an email address for this local visual demo.":"Enter your email address to continue.";document.getElementById("email").value="";document.getElementById("emailNote").textContent="Local visual demo only. No email is sent.";showScreen("modalScreen");showPage("emailPage")}
document.getElementById("loginBtn").addEventListener("click",()=>openFlow("login"));
document.getElementById("createBtn").addEventListener("click",()=>openFlow("create"));
document.getElementById("closeBtn").addEventListener("click",()=>showScreen("landing"));
document.getElementById("emailCancel").addEventListener("click",()=>showScreen("landing"));
document.getElementById("emailContinue").addEventListener("click",()=>{
 const email=document.getElementById("email"),note=document.getElementById("emailNote");
 if(!email.value.trim()||!email.checkValidity()){note.textContent="Enter a valid-looking email address to continue.";note.style.color="#b33";email.focus();return}
 note.textContent="Demo only: no email is sent and no address is stored.";note.style.color="#8b9490";showPage("verifyPage");
});
const digits=[...document.querySelectorAll(".code-digit")],submit=document.getElementById("submitCode"),hint=document.getElementById("codeHint");
function updateCode(){const full=digits.every(x=>/^\d$/.test(x.value));submit.disabled=!full;hint.textContent=full?"Demo code entered. You can continue.":"Digite seis dígitos fictícios para habilitar o botão."}
digits.forEach((input,i)=>{
 input.addEventListener("input",()=>{input.value=input.value.replace(/\D/g,"").slice(-1);if(input.value&&i<digits.length-1)digits[i+1].focus();updateCode()});
 input.addEventListener("keydown",e=>{if(e.key==="Backspace"&&!input.value&&i>0)digits[i-1].focus()});
 input.addEventListener("paste",e=>{e.preventDefault();const val=(e.clipboardData||window.clipboardData).getData("text").replace(/\D/g,"").slice(0,6);val.split("").forEach((d,j)=>digits[j].value=d);digits[Math.min(val.length,5)].focus();updateCode()});
});
document.getElementById("cancelVerify").addEventListener("click",()=>showPage("emailPage"));
submit.addEventListener("click",()=>{if(!submit.disabled)showPage("confirmPage")});
document.getElementById("cancelConfirm").addEventListener("click",()=>showPage("verifyPage"));
document.getElementById("confirmConnect").addEventListener("click",()=>showPage("donePage"));
document.getElementById("finishBtn").addEventListener("click",()=>{digits.forEach(x=>x.value="");updateCode();showScreen("landing")});
document.getElementById("aboutBtn").addEventListener("click",()=>showScreen("aboutPage"));
document.getElementById("aboutClose").addEventListener("click",()=>showScreen("landing"));
document.getElementById("aboutBack").addEventListener("click",()=>showScreen("landing"));
