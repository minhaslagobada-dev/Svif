# Supercell ID clássico — réplica visual independente

Esta é uma demonstração local inspirada nas capturas de tela fornecidas. A tela inicial segue a referência com arte à esquerda e os botões **INICIAR SESSÃO** e **CRIAR ID** à direita. A tela de verificação possui seis campos; o botão SUBMIT só fica ativo quando todos têm um dígito.

## Executar
Extraia o ZIP e abra `index.html` em um navegador moderno. Não requer instalação.

## Arquivos
- `index.html` — estrutura e telas
- `styles.css` — layout responsivo e botões com relevo
- `script.js` — navegação e interação dos seis dígitos
- `references/` — imagens fornecidas e recortes usados no layout

## Limites importantes
Réplica visual independente, não oficial. Não envia e-mails, não coleta nem armazena endereços, não valida códigos reais e não conecta contas da Supercell. O código digitado é fictício e serve apenas para demonstrar a mudança visual do botão.
